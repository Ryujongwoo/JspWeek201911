package kr.koreait.calendar;

//	달력 작업에 필요한 메소드를 모아놓은 클래스
public class MyCalendar {

//	윤년/평년 판별 메소드
//	년도를 넘겨받아 윤년/평년을 판단해 윤년이면 true, 평년이면 false를 리턴하는 메소드
	public static boolean isLeapYear(int year) {
//		년도가 4로 나눠 떨어지고 100으로 나눠 떨어지지 않거나 400으로 나눠 떨어지면 윤년, 그렇치 않으면 평년
		return year % 4 == 0 && year % 100 != 0 || year % 400 == 0;
	}
	
//	년, 월을 인수로 넘겨받아 그 달의 마지막 날짜를 리턴하는 메소드
	public static int lastDay(int year, int month) {
//		각 달의 마지막 날짜를 기억하는 배열을 만든다.
		int[] m = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
//		2월의 마지막 날짜를 결정한다.
		m[1] = isLeapYear(year) ? 29 : 28;
//		마지막 날짜를 리턴시킨다.
		return m[month - 1];
	}
	
//	년, 월, 일을 인수로 넘겨받아 1년 1월 1일 부터 지나온 날짜의 합계를 리턴하는 메소드
	public static int totalDay(int year, int month, int day) {
//		1년 1월 1일 부터 전년도 12월 31일 까지 지난 날짜를 계산한다.
		int sum = (year - 1) * 365 + (year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400;
//		전년도 까지 지난 날짜의 합계에 전달 까지 지난 날짜를 더한다.
		for(int i = 1; i < month; i++) {
			sum += lastDay(year, i);
		}
//		전달 까지 지난 날짜의 합계에 일을 더해서 리턴시킨다.
		return sum + day;
	}
	
//	년, 월, 일을 인수로 넘겨받아 요일을 숫자로 리턴하는 메소드
//	일요일(0), 월요일(1), 화요일(2), 수요일(3), 목요일(4), 금요일(5), 토요일(6)
	public static int weekDay(int year, int month, int day) {
		return totalDay(year, month, day) % 7;
	}
	
}










