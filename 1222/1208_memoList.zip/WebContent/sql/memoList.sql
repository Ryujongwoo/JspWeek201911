# INSERT => 테이블에 데이터를 저장한다.
# INSERT INTO 테이블이름 (필드이름, ...) VALUES (저장할 데이터, ...)
# 저장할 데이터가 문자열일 경우 반드시 작은따옴표로 묶어야 한다.
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('홍길동', '1111', '1등 입니다.', '192.168.2.101');
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('임꺽정', '2222', '2등 입니다.', '192.168.2.102');
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('장길산', '3333', '3등 입니다.', '192.168.2.103');
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('일지매', '4444', '4등 입니다.', '192.168.2.104');

# SELECT => 테이블에 저장된 데이터를 얻어온다.
# SELECT [필드이름 또는 *] FROM 테이블이름 => 전체 레코드를 얻어온다.
SELECT * FROM memo;
SELECT NAME, memo FROM memo;
# SELECT [필드이름 또는 *] FROM 테이블이름 WHERE 조건식 => 조건에 만족하는 레코드를 얻어온다.
SELECT * FROM memo WHERE NAME = '홍길동';
SELECT * FROM memo WHERE NAME = '홍길동' || NAME = '임꺽정';
SELECT * FROM memo WHERE NAME = '장길산' OR NAME = '일지매';
# IN 연산자를 사용하면 ()안에 나열된 조건을 만족하는 레코드만 얻어올 수 있다.
SELECT * FROM memo WHERE NAME IN('홍길동', '임꺽정', '장길산');
# NOT IN 연산자를 사용하면 ()안에 나열된 조건을 만족하지 않는 레코드만 얻어올 수 있다.
SELECT * FROM memo WHERE NAME NOT IN('홍길동', '임꺽정', '장길산');
SELECT * FROM memo WHERE idx = 3;
SELECT * FROM memo WHERE idx >= 3 && idx <= 5;
SELECT * FROM memo WHERE idx >= 1 AND idx <= 4;
# BETWEEN 연산자를 사용하면 AND 연산과 동일한 결과를 얻을 수 있다. 단, 초과 또는 미만 조건은 사용할 수 없다.
SELECT * FROM memo WHERE idx BETWEEN 1 AND 5;
# LIKE(부분 일치) 연산자와 와일드 카드(대체) 문자('_' => 1문자, '%' => 여러문자)를 사용해 부분 일치 조건을
# 지정할 수 있다. => 검색
# 역삼_동 => 역삼1동, 역삼2동, 역삼3동...
# 역삼% => 앞의 2자는 역삼이고 뒤에는 뭐가 나와도 상관없다. => 역삼으로 시작하는
# %역삼 => 뒤의 2자는 역삼이고 앞에는 뭐가 나와도 상관없다. => 역삼으로 끝나는
# %역삼% => 역삼을 포함하는
SELECT * FROM memo WHERE NAME LIKE '홍%';
SELECT * FROM memo WHERE NAME LIKE '%정';
SELECT * FROM memo WHERE NAME LIKE '%길%';
# SELECT [필드이름 또는 *] FROM 테이블이름 ORDER BY 필드이름 [ASC 또는 DESC] => 정렬
# ASC => 생략시 기본값, 오름차순, DESC => 내림차순
SELECT * FROM memo ORDER BY NAME;
SELECT * FROM memo ORDER BY NAME ASC;
SELECT * FROM memo ORDER BY NAME DESC;
SELECT * FROM memo ORDER BY NAME ASC, idx DESC; # 이름이 같으면 글번호의 내림차순으로 정렬한다.
# SELECT [필드이름 또는 *] FROM 테이블이름 LIMIT 시작인덱스번호, 개수
# LIMIT를 사용하면 지정된 인덱스 번호의 레코드 부터 지정된 개수 만큼의 레코드를 얻어온다.
# 인덱스는 SELECT 명령을 실행했을 때 결과가 출력되는 순서를 의미한다.
# MYSQL은 인덱스가 0 부터 시작되고 ORACLE은 인덱스가 1 부터 시작된다.
SELECT * FROM memo ORDER BY idx ASC LIMIT 0, 3;
SELECT * FROM memo ORDER BY idx DESC LIMIT 0, 3;
# GROUP 함수 : SUM(필드이름) => 합계, AVG(필드이름) => 평균, MAX(필드이름) => 최대값, MIN(필드이름) => 최소값
# COUNT(*) => 개수, 개수는 어떤 필드의 개수를 세도 똑같이 나오기 때문에 () 안에 "*"을 써주면 된다.
SELECT COUNT(*) FROM memo;
SELECT COUNT(*) AS '인원수' FROM memo; # AS를 사용해 필드의 별명을 지정할 수 있다.
SELECT SUM(idx) FROM memo;
SELECT AVG(idx) FROM memo;
SELECT MAX(idx) FROM memo;
SELECT MIN(idx) FROM memo;
# SELECT [필드이름 또는 *] FROM 테이블이름 GROUP BY 필드이름;
# GROUP BY에 지정된 필드를 기준으로 그룹으로 묶는다. => GROUP 함수와 같이 사용한다. => 소계
SELECT NAME, SUM(idx) FROM memo GROUP BY NAME;
# SELECT [필드이름 또는 *] FROM 테이블이름 GROUP BY 필드이름 HAVING 조건식; => HAVING으로 GROUP 조건을 지정한다.
SELECT NAME, SUM(idx) FROM memo GROUP BY NAME HAVING NAME LIKE '%길%';
SELECT * FROM memo ORDER BY idx DESC;


DELETE FROM memo;
ALTER TABLE memo AUTO_INCREMENT = 1;