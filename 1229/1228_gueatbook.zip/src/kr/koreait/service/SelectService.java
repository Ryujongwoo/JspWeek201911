package kr.koreait.service;

import java.sql.SQLException;
import java.util.HashMap;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.koreait.dao.GuestbookDAO;
import kr.koreait.ibatis.MyAppSqlConfig;
import kr.koreait.vo.GuestbookList;

public class SelectService {

	private static SelectService instance = new SelectService();
	private SelectService() { }
	public static SelectService getInstance() { return instance; }

//	list.jsp에서 호출되는 화면에 표시할 페이지 번호를 넘겨받고 mapper를 얻어온 후 GuestbookDAO 클래스의 한 페이지 
//	분량의 글을 얻어오는 메소드를 호출하는 메소드
	public GuestbookList selectList(int currentPage) {
		System.out.println("SelectService 클래스의 selectList() 메소드 실행");
		SqlMapClient mapper = MyAppSqlConfig.getSqlMapInstance();
//		1페이지 분량의 글과 페이지 작업에 사용할 8개의 변수를 저장해서 리턴시킬 객체를 선언한다.
		GuestbookList guestbookList = null;
		GuestbookDAO dao = GuestbookDAO.getInstance();
		
		try {
//			1페이지에 표시할 글의 개수를 정한다.
			int pageSize = 10;
//			테이블에 저장된 전체 글의 개수를 얻어온다.
			int totalCount = dao.selectCount(mapper);
//			System.out.println(totalCount);
			
//			pageSize, totalCount, currentPage를 GuestbookList 클래스의 생성자로 넘겨서 1페이지 분량의 글과 페이지
//			작업에 사용할 8개의 변수를 초기화 시키는 클래스의 객체를 생성한다.
			guestbookList = new GuestbookList(pageSize, totalCount, currentPage); // 8개의 변수가 계산된다.
			
//			mysql을 사용할 때는 startNo와 pageSize를 사용해 limit를 사용해서 1페이지 분량의 글을 얻어왔지만 오라클은
//			limit가 없기 때문에 startNo와 endNo를 sql 명령으로 넘겨서 startNo와 endNo 사이의 글 목록을 얻어와야 한다.
//			xml 파일의 parameterClass에는 1개의 자료형만 쓸 수 있기 때문에 startNo와 endNo는 모두 int 타입이므로
//			HashMap 객체를 만들어 startNo와 endNo를 저장시켜 xml 파일로 넘겨준다.
			HashMap<String, Integer> hmap = new HashMap<String, Integer>();
			hmap.put("startNo", guestbookList.getStartNo());
			hmap.put("endNo", guestbookList.getEndNo());
			
//			1페이지 분량의 글을 얻어와서 GuestbookList 클래스 객체의 ArrayList에 저장한다.
			guestbookList.setGuestbookList(dao.selectList(mapper, hmap));
			System.out.println(guestbookList);
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
//		1페이지 분량의 글과 페이지 작업에 사용할 8개의 변수를 저장한 객체를 리턴시킨다.
		return guestbookList;
	}
	
}












