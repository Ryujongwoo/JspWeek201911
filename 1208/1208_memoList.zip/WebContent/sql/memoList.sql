# INSERT => 테이블에 데이터를 저장한다.
# INSERT INTO 테이블이름 (필드이름, ...) VALUES (저장할 데이터, ...)
# 저장할 데이터가 문자열일 경우 반드시 작은따옴표로 묶어야 한다.
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('홍길동', '1111', '1등 입니다.', '192.168.2.101');