package kr.koreait.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.vo.CategoryVO;

public class CategoryDAO {

	private static CategoryDAO instance = new CategoryDAO();
	private CategoryDAO() { }
	public static CategoryDAO getInstance() { return instance; }

//	CaterotyService 클래스에서 호출되는 mapper와 테이블에 저장할 메인 카테고리 데이터가 저장된 객체를 넘겨받고 테이블에
//	저장하는 category.xml 파일의 insert sql 명령을 실행하는 메소드
	public void insert(SqlSession mapper, CategoryVO vo) {
		System.out.println("CategoryDAO 클래스의 insert() 메소드 실행");
		mapper.insert("insert", vo);
	}
	public ArrayList<CategoryVO> selectList(SqlSession mapper) {
		System.out.println("CategoryDAO 클래스의 selectList() 메소드 실행");
//		selectOne() => ibatis의 queryForObject()와 같은 기능을 실행한다. => 결과가 1개인 select => Object 타입이 리턴
//		selectList() => ibatis의 queryForList()와 같은 기능을 실행한다. => 결과가 여러개인 select => List 타입이 리턴
		return (ArrayList<CategoryVO>) mapper.selectList("selectList");
	}
	
//	CaterotyService 클래스에서 호출되는 mapper와 ref, lev가 저장된 HashMap 객체를 넘겨받고 같은 카테고리 그룹에서 조건에
//	만족하는 카테고리의 출력 순서를 조정하기 위해 seq를 1증가 시키는 category.xml 파일의 update sql 명령을 실행하는 메소드
	public void increment(SqlSession mapper, HashMap<String, Integer> hmap) {
		System.out.println("CategoryDAO 클래스의 increment() 메소드 실행");
		mapper.update("increment", hmap);
	}
	
//	CaterotyService 클래스에서 호출되는 mapper와 테이블에 저장할 서브 카테고리 데이터가 저장된 객체를 넘겨받고 테이블에
//	저장하는 category.xml 파일의 insert sql 명령을 실행하는 메소드
	public void reply(SqlSession mapper, CategoryVO vo) {
		System.out.println("CategoryDAO 클래스의 reply() 메소드 실행");
		mapper.insert("reply", vo);
	}
	
//	CaterotyService 클래스에서 호출되는 mapper와 카테고리 번호를 넘겨받고 테이블에서 카테고리 1건을 얻어오는 category.xml 
//	파일의 select sql 명령을 실행하는 메소드
	public CategoryVO selectByIdx(SqlSession mapper, int idx) {
		System.out.println("CategoryDAO 클래스의 selectByIdx() 메소드 실행");
		return (CategoryVO) mapper.selectOne("selectByIdx", idx);
	}
	
//	CaterotyService 클래스에서 호출되는 mapper와 삭제할 카테고리 번호를 넘겨받고 테이블에서 카테고리 1건을 삭제하는 
//	category.xml 파일의 delete sql 명령을 실행하는 메소드
	public void delete(SqlSession mapper, int idx) {
		System.out.println("CategoryDAO 클래스의 delete() 메소드 실행");
		mapper.delete("delete", idx);
	}
	
//	CaterotyService 클래스에서 호출되는 mapper와 수정할 카테고리 정보가 저장된 객체를 넘겨받고 테이블에서 카테고리 1건을 
//	수정하는 category.xml 파일의 update sql 명령을 실행하는 메소드
	public void update(SqlSession mapper, CategoryVO vo) {
		System.out.println("CategoryDAO 클래스의 update() 메소드 실행");
		mapper.update("update", vo);
	}

}
