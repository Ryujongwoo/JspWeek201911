package kr.koreait.mvcBoard;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.koreait.service.MvcBoardService;

@WebServlet("*.nhn")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HomeController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		System.out.println("컨트롤러의 doGet() 메소드 실행");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		request.setCharacterEncoding("UTF-8");
//		System.out.println("컨트롤러의 doPost() 메소드 실행");
//		System.out.println(request.getParameter("name"));
//		System.out.println(request.getParameter("subject"));
//		System.out.println(request.getParameter("content"));
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
//		System.out.println("컨트롤러의 actionDo() 메소드 실행");
//		System.out.println(request.getParameter("name"));
//		System.out.println(request.getParameter("subject"));
//		System.out.println(request.getParameter("content"));
		
		String url = request.getRequestURI();
		String contextPath = request.getContextPath();
		String context = url.substring(contextPath.length());
//		System.out.println(context);
		
		String viewPage = "/WEB-INF/";
		switch (context) {
			case "/insert.nhn":
				viewPage += "insert.jsp";
				break;
			case "/insertOK.nhn":
				
//				insert.jsp에서 테이블에 저장할 데이터를 입력하고 submit 버튼을 클릭하면 폼에 입력된 정보가 컨트롤러의
//				doPost() 메소드의 HttpServletRequest 인터페이스 타입의 객체 request로 전달된다.
//				doPost() 메소드에서는 HttpServletRequest 인터페이스 타입의 객체 request로 전달된 데이터를 가지고 actionDo()
//				메소드를 실행하므로 actionDo() HttpServletRequest 인터페이스 타입의 객체 request로 insert.jsp에서 폼에
//				입력한 데이터가 전달된다.
				
//				insert.jsp의 폼에 입력한 데이터를 테이블에 저장하는 메소드를 호출한다.
				MvcBoardService.getInstance().insert(request, response);
				
				viewPage += "insert.jsp";
				break;
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
		
	}

}









