package kr.koreait.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.dao.MvcBoardDAO;
import kr.koreait.mybatis.MySession;
import kr.koreaot.vo.MvcBoardVO;

public class MvcBoardService {

	private static MvcBoardService instance = new MvcBoardService();
	private MvcBoardService() { }
	public static MvcBoardService getInstance() { return instance; }
	
//	insertOK.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 메소드로 저장할 메인글이 저장된 request 객체를 넘겨받고 mapper를
//	얻어오는 메소드
	public void insert(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 insert() 메소드 실행");
//		System.out.println(request.getParameter("name"));
//		System.out.println(request.getParameter("subject"));
//		System.out.println(request.getParameter("content"));
		SqlSession mapper = MySession.getSession();
		
//		request 객체로 넘어온 insert.jsp에서 폼에 입력한 데이터를 받아서 MvcBoardVO 클래스 객체에 저장한다.
		MvcBoardVO vo = new MvcBoardVO();
		vo.setName(request.getParameter("name"));
		vo.setSubject(request.getParameter("subject"));
		vo.setContent(request.getParameter("content"));
		
//		DAO 클래스의 insert.jsp에서 입력한 데이터를 저장하는 insert sql 명령을 실행하는 메소드를 호출한다.
		MvcBoardDAO.getInstance().insert(mapper, vo);
		
		mapper.commit();
		mapper.close();
	}
	
}



