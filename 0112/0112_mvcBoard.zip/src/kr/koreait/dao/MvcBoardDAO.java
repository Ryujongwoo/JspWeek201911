package kr.koreait.dao;

import org.apache.ibatis.session.SqlSession;

import kr.koreaot.vo.MvcBoardVO;

public class MvcBoardDAO {

	private static MvcBoardDAO instance = new MvcBoardDAO();
	private MvcBoardDAO() { }
	public static MvcBoardDAO getInstance() { return instance; }

//	MvcBoardService 클래스에서 mapper와 테이블에 저장할 메인글 데이터가 저장된 객체를 넘겨받고 메인글을 테이블에 저장하는
//	mvcboard.xml 파일의 insert sql 명령을 실행하는 메소드
	public void insert(SqlSession mapper, MvcBoardVO vo) {
		System.out.println("MvcBoardDAO 클래스의 insert() 메소드 실행");
		mapper.insert("insert", vo);
	}
	
}
